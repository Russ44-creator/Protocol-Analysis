/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright (C) 2020 Marvell International Ltd.
 */

#ifndef _OTX2_REGEXDEV_COMPILER_H_
#define _OTX2_REGEXDEV_COMPILER_H_

int
otx2_ree_rule_db_compile_prog(struct rte_regexdev *dev);

#endif /* _OTX2_REGEXDEV_COMPILER_H_ */
